package com.srl.touchandgo;

public class Utils
{
    final static int CAMERA_ZOOM = 15;
    final static String TAG = "touch_and_go";
}
